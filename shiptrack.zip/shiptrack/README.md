# ShipTrack
1. Node 18+ install karo.
2. `cp .env.example .env` aur values bharo.
3. `node server.js` -> http://localhost:3000 (login: APP_USER / APP_PASSWORD)

## Real tracking (Terminal49)
- .env: PROVIDER=terminal49, TERMINAL49_API_KEY=...
- Terminal49 dashboard > Webhooks: URL = https://APKA-DOMAIN/webhook?secret=WEBHOOK_SECRET
  (webhook aate hi instant check + alert; warna har POLL_MINUTES par check)

## Telegram alert
@BotFather se bot banao -> token. Bot ko /start bhejo, phir chat id @userinfobot se lo.
