// ShipTrack - auto shipment tracking + instant ETA-change alerts
// Zero dependencies. Needs Node 18+.  Run: node server.js
const http = require('http');
const fs = require('fs');
const path = require('path');

// ---- load .env (simple) ----
try {
  for (const l of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split('\n')) {
    const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2];
  }
} catch {}

const C = {
  port: +process.env.PORT || 3000,
  provider: process.env.PROVIDER || 'mock', // mock | terminal49
  t49Key: process.env.TERMINAL49_API_KEY || '',
  tgToken: process.env.TELEGRAM_BOT_TOKEN || '',
  tgChat: process.env.TELEGRAM_CHAT_ID || '',
  pollMin: +process.env.POLL_MINUTES || 30,
  user: process.env.APP_USER || 'admin',
  pass: process.env.APP_PASSWORD || 'admin123',
  webhookSecret: process.env.WEBHOOK_SECRET || 'change-me',
};

// ---- tiny JSON storage ----
const DB = path.join(process.env.DATA_DIR || __dirname, 'data.json');
let db = { shipments: [], alerts: [] };
try { db = JSON.parse(fs.readFileSync(DB, 'utf8')); } catch {}
const save = () => fs.writeFileSync(DB, JSON.stringify(db, null, 2));

// ---- notifications ----
async function notify(text) {
  db.alerts.unshift({ at: new Date().toISOString(), text });
  db.alerts = db.alerts.slice(0, 200);
  save();
  console.log('[ALERT]', text);
  if (C.tgToken && C.tgChat) {
    try {
      await fetch(`https://api.telegram.org/bot${C.tgToken}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: C.tgChat, text }),
      });
    } catch (e) { console.error('Telegram error', e.message); }
  }
}

// ---- providers: return { eta, status } for a shipment ----
const providers = {
  async mock(s) {
    // demo only: 40% chance ETA moves by +/-1-2 days each check
    const base = s.eta ? new Date(s.eta) : new Date(Date.now() + 10 * 864e5);
    if (s.eta && Math.random() < 0.4) base.setDate(base.getDate() + (Math.random() < 0.5 ? 1 : -1) * (1 + Math.floor(Math.random() * 2)));
    return { eta: base.toISOString(), status: 'In transit' };
  },
  async terminal49(s) {
    // Terminal49 API v2 (JSON:API). Shipment must be tracked first (see addShipment).
    const h = { Authorization: `Token ${C.t49Key}`, 'Content-Type': 'application/vnd.api+json' };
    const r = await fetch(`https://api.terminal49.com/v2/shipments?q=${encodeURIComponent(s.ref)}`, { headers: h });
    if (!r.ok) throw new Error('Terminal49 HTTP ' + r.status);
    const j = await r.json();
    const sh = (j.data || [])[0];
    if (!sh) return { eta: s.eta, status: 'Waiting for carrier data' };
    const a = sh.attributes || {};
    return {
      eta: a.pod_eta_at || a.pod_original_eta_at || s.eta,
      status: a.pod_arrived_at ? 'Arrived' : a.pod_atd_at ? 'In transit' : 'Booked',
    };
  },
};

async function startTracking(s) {
  if (C.provider !== 'terminal49') return;
  const r = await fetch('https://api.terminal49.com/v2/tracking_requests', {
    method: 'POST',
    headers: { Authorization: `Token ${C.t49Key}`, 'Content-Type': 'application/vnd.api+json' },
    body: JSON.stringify({ data: { type: 'tracking_request', attributes: {
      request_type: s.type === 'container' ? 'container' : 'bill_of_lading',
      request_number: s.ref, scac: s.carrier } } }),
  });
  if (!r.ok) console.error('tracking_request failed', r.status, await r.text());
}

// ---- core: refresh one shipment and alert on ETA change ----
async function refresh(s) {
  try {
    const res = await providers[C.provider](s);
    s.lastChecked = new Date().toISOString();
    s.error = null;
    if (res.status && res.status !== s.status) {
      if (s.status) await notify(`📦 ${s.ref}: status ${s.status} → ${res.status}`);
      s.status = res.status;
    }
    if (res.eta && s.eta && new Date(res.eta).getTime() !== new Date(s.eta).getTime()) {
      const d = Math.round((new Date(res.eta) - new Date(s.eta)) / 864e5);
      const dir = d > 0 ? `${d} din DELAY ⚠️` : `${-d} din JALDI ✅`;
      s.history.unshift({ at: s.lastChecked, from: s.eta, to: res.eta });
      await notify(`🚢 ETA CHANGE – ${s.ref} (${s.carrier})\nPurana: ${s.eta.slice(0, 10)}\nNaya: ${res.eta.slice(0, 10)}\n${dir}`);
    }
    if (res.eta) s.eta = res.eta;
  } catch (e) {
    s.error = e.message;
    console.error('refresh error', s.ref, e.message);
  }
  save();
}
const refreshAll = async () => { for (const s of db.shipments) if (s.status !== 'Arrived') await refresh(s); };
setInterval(refreshAll, C.pollMin * 60 * 1000);

// ---- http server ----
const send = (res, code, body, type = 'application/json') => {
  res.writeHead(code, { 'Content-Type': type });
  res.end(type === 'application/json' ? JSON.stringify(body) : body);
};
const readBody = req => new Promise(r => { let b = ''; req.on('data', d => b += d); req.on('end', () => { try { r(JSON.parse(b || '{}')); } catch { r({}); } }); });
const authed = req => {
  const h = req.headers.authorization || '';
  if (!h.startsWith('Basic ')) return false;
  return Buffer.from(h.slice(6), 'base64').toString() === `${C.user}:${C.pass}`;
};

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');

  // Provider webhook (Terminal49 -> us): triggers an immediate refresh = instant alerts
  if (url.pathname === '/webhook' && req.method === 'POST') {
    if (url.searchParams.get('secret') !== C.webhookSecret) return send(res, 401, { error: 'bad secret' });
    send(res, 200, { ok: true });
    refreshAll();
    return;
  }

  if (!authed(req)) {
    res.writeHead(401, { 'WWW-Authenticate': 'Basic realm="ShipTrack"' });
    return res.end('Login required');
  }

  if (url.pathname === '/' ) return send(res, 200, fs.readFileSync(path.join(__dirname, 'index.html')), 'text/html; charset=utf-8');
  if (url.pathname === '/api/shipments' && req.method === 'GET') return send(res, 200, { shipments: db.shipments, alerts: db.alerts, provider: C.provider });

  if (url.pathname === '/api/shipments' && req.method === 'POST') {
    const b = await readBody(req);
    if (!b.ref) return send(res, 400, { error: 'ref required' });
    const s = { id: Date.now().toString(36), ref: b.ref.trim().toUpperCase(), carrier: (b.carrier || '').toUpperCase(),
      type: b.type === 'container' ? 'container' : 'bl', status: '', eta: null, history: [], lastChecked: null };
    db.shipments.push(s); save();
    await startTracking(s);
    await refresh(s);
    return send(res, 200, s);
  }
  if (url.pathname.startsWith('/api/shipments/') && req.method === 'DELETE') {
    db.shipments = db.shipments.filter(x => x.id !== url.pathname.split('/').pop()); save();
    return send(res, 200, { ok: true });
  }
  if (url.pathname === '/api/refresh' && req.method === 'POST') { await refreshAll(); return send(res, 200, { ok: true }); }
  if (url.pathname === '/api/test-alert' && req.method === 'POST') { await notify('✅ ShipTrack test alert – notifications kaam kar rahe hain'); return send(res, 200, { ok: true }); }
  send(res, 404, { error: 'not found' });
}).listen(C.port, () => console.log(`ShipTrack running: http://localhost:${C.port}  (provider: ${C.provider})`));
