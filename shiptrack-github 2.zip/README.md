# ShipTrack – shipment auto tracking + instant ETA change alerts

- `docs/index.html` : DEMO page (GitHub Pages par chalta hai, nakli data)
- `server.js` + `index.html` : ASLI software (Node.js server chahiye; Render/Replit/VPS par chalayen)

## Demo ko GitHub Pages par kholna
Repo > Settings > Pages > Source: "Deploy from a branch" > Branch: main, Folder: /docs > Save.
1-2 minute baad link: https://USERNAME.github.io/REPO-NAME/

## Asli software chalana
1. `cp .env.example .env` aur values bharo
2. `node server.js` -> http://localhost:3000
3. Online chalane ke liye Render: Start command `npm start`, env vars dalo, `DATA_DIR=/data` + Disk `/data`
4. Terminal49 webhook: https://APKA-LINK/webhook?secret=WEBHOOK_SECRET
5. Telegram: @BotFather se bot banao, token + chat id .env mein
